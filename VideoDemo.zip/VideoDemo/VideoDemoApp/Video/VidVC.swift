//
//  VidVC.swift
//  VideoDemoApp
//
//  Created by Ani Adhikary on 11/05/23.
//

import UIKit
import WebKit

class VidVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }

    func setupView() {
        // Create a ContainerView to hold the content
        let containerView = UIView()
        containerView.translatesAutoresizingMaskIntoConstraints = false
        containerView.backgroundColor = .white
        view.addSubview(containerView)
        
        // Add constraints to the ContainerView
        containerView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        containerView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        containerView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        containerView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        
        // Create a UIScrollView
        let scrollView = UIScrollView()
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        containerView.addSubview(scrollView)
        
        // Add constraints to the scroll view
        scrollView.leadingAnchor.constraint(equalTo: containerView.leadingAnchor).isActive = true
        scrollView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor).isActive = true
        scrollView.topAnchor.constraint(equalTo: containerView.topAnchor).isActive = true
        scrollView.bottomAnchor.constraint(equalTo: containerView.bottomAnchor).isActive = true
        
        
        // Create a container view to hold the content
        let contentContainerView = UIView()
        contentContainerView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(contentContainerView)
        
        // Add constraints to the content container view
        contentContainerView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        contentContainerView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        contentContainerView.topAnchor.constraint(equalTo: scrollView.topAnchor).isActive = true
        contentContainerView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor).isActive = true
        contentContainerView.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
        
        // Create a UILabel
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Hello World! This is a multi-line label using a custom font."
        label.numberOfLines = 0
        label.font = UIFont(name: "Helvetica Neue", size: 20)
        contentContainerView.addSubview(label)
        
        // Add constraints to the label
        label.centerXAnchor.constraint(equalTo: contentContainerView.centerXAnchor).isActive = true
        label.topAnchor.constraint(equalTo: contentContainerView.topAnchor, constant: 50).isActive = true
        label.leadingAnchor.constraint(equalTo: contentContainerView.leadingAnchor, constant: 16).isActive = true
        label.trailingAnchor.constraint(equalTo: contentContainerView.trailingAnchor, constant: -16).isActive = true
        
        // Create a WKWebView
        let webView = WKWebView()
        webView.translatesAutoresizingMaskIntoConstraints = false
//        webView.load(URLRequest(url: URL(string: "https://www.apple.com")!))
//        contentContainerView.addSubview(webView)
        
        if let url = URL(string: "https://players.brightcove.net/1496514754001/default_default/index.html?videoId=6320450078112") {
            let request = URLRequest(url: url)
            webView.load(request)
        }
        
        contentContainerView.addSubview(webView)
        
        // Add constraints to the web view
        webView.centerXAnchor.constraint(equalTo: containerView.centerXAnchor).isActive = true
        webView.topAnchor.constraint(equalTo: label.bottomAnchor, constant: 50).isActive = true
        webView.widthAnchor.constraint(equalToConstant: 400).isActive = true
        webView.heightAnchor.constraint(equalToConstant: 350).isActive = true
        webView.leadingAnchor.constraint(equalTo: contentContainerView.leadingAnchor, constant: 16).isActive = true
        webView.trailingAnchor.constraint(equalTo: contentContainerView.trailingAnchor, constant: -16).isActive = true
        webView.bottomAnchor.constraint(equalTo: contentContainerView.bottomAnchor, constant: -50).isActive = true
        
        
        // Set the content size of the scroll view
        contentContainerView.bottomAnchor.constraint(equalTo: webView.bottomAnchor, constant: 50).isActive = true
    }
}

