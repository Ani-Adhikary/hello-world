import UIKit
import WebKit

class MainVC: UIViewController {
    
    // MARK: - Properties
    
    let tableView: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.accessibilityIdentifier = "myTableView"
        return tableView
    }()
    
    // MARK: - Lifecycle Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configureTableView()
    }
    
    // MARK: - Private Methods
    
    private func configureTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.register(HeadingCell.self, forCellReuseIdentifier: "LabelCell")
        tableView.register(VideoCell.self, forCellReuseIdentifier: "WebViewCell")
        
        view.addSubview(tableView)
        
        NSLayoutConstraint.activate([
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ])
    }
}

// MARK: - UITableViewDelegate

extension MainVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return UITableView.automaticDimension
        } else {
            return 400
        }
    }
    
    func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
            if indexPath.row == 0 {
                return false // Disable selection for the first cell
            } else {
                return true // Enable selection for other cells
            }
        }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
}

// MARK: - UITableViewDataSource

extension MainVC: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "LabelCell", for: indexPath) as! HeadingCell
            cell.label.text = "This is a multiline label with a custom font. This is a multiline label with a custom font. This is a multiline label with a custom font. This is a multiline label with a custom font. This is a multiline label with a custom font. This is a multiline label with a custom font. This is a multiline label with a custom font. This is a multiline label with a custom font. This is a multiline label with a custom font."
            
            // Accessibility
            cell.label.isAccessibilityElement = true
            cell.label.accessibilityLabel = "Multiline Label"
            cell.label.accessibilityTraits = .staticText
            cell.label.accessibilityIdentifier = "multilineLabel"
            
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "WebViewCell", for: indexPath) as! VideoCell
           let videoURL = URL(string: "https://players.brightcove.net/1496514754001/default_default/index.html?videoId=6320450078112")!
            
            //let videoURL = URL(string: "https://www.apple.com/")!
            let request = URLRequest(url: videoURL)
            cell.webView.load(request)
            
            // Accessibility
            cell.webView.isAccessibilityElement = true
            cell.webView.accessibilityLabel = "Video Player"
            cell.webView.accessibilityTraits = .staticText
            cell.webView.accessibilityIdentifier = "videoPlayer"
            
            return cell
        }
    }
}

