//
//  VideoCell.swift
//  VideoDemoApp
//
//  Created by Ani Adhikary on 17/05/23.
//

import UIKit
import WebKit

class VideoCell: UITableViewCell {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    // MARK: - Properties
    
    lazy var webView: WKWebView = {
        let webView = WKWebView()
        webView.translatesAutoresizingMaskIntoConstraints = false
        webView.isAccessibilityElement = true
        //webView.accessibilityTraits = .staticText
        webView.accessibilityIdentifier = "VideoCell"
        return webView
    }()
    
    // MARK: - Initialization
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        contentView.addSubview(webView)
        
        NSLayoutConstraint.activate([
            webView.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            webView.topAnchor.constraint(equalTo: contentView.bottomAnchor, constant: 50),
            webView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            webView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            webView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -50),
            webView.widthAnchor.constraint(equalToConstant: 400),
            webView.heightAnchor.constraint(equalToConstant: 350)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
