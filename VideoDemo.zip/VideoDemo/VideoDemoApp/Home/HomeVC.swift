//
//  HomeVC.swift
//  VideoDemoApp
//
//  Created by Ani Adhikary on 05/05/23.
//

import UIKit

class HomeVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
