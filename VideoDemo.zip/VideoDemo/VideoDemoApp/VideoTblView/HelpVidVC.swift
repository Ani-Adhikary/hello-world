import UIKit

class HelpVidVC: UIViewController {
    
    let tableView: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Add the tableView to the view hierarchy
        view.addSubview(tableView)
        configureTableView()
    }
    
    private func configureTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.register(HelpVideoCell.self, forCellReuseIdentifier: "HelpVideoCell")
        
        view.addSubview(tableView)
        
        NSLayoutConstraint.activate([
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ])
    }
}

extension HelpVidVC: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "HelpVideoCell", for: indexPath) as? HelpVideoCell else {
            fatalError("Unable to dequeue HelpVideoCell")
        }
        
        // Configure the cell
        cell.label.text = "This is a multiline label with a custom font. This is a multiline label with a custom font. This is a multiline label with a custom font.This is a multiline label with a custom font. This is a multiline label with a custom font."
        if let videoURL = URL(string: "https://players.brightcove.net/1496514754001/default_default/index.html?videoId=6320450078112") {
            let request = URLRequest(url: videoURL)
            cell.webView.load(request)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
}

