//
//  HomeVC.swift
//  VideoDemoApp
//
//  Created by Ani Adhikary on 05/05/23.
//

import UIKit
import AVKit
import AVFoundation

class HomeVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
        
    @IBAction func playVideoAction(_ sender: UIButton) {
        guard let url = URL(string: "https://samplelib.com/lib/preview/mp4/sample-5s.mp4")else {return}
        
        guard let url = URL(string: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4")else {return}
        
        // guard let url = URL(string: "http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4")else {return}
        let player = AVPlayer(url: url)
        var playerController = AVPlayerViewController()
        playerController.player = player
        playerController.allowsPictureInPicturePlayback = true
        playerController.player?.play()
        self.present(playerController, animated: true, completion: nil)
    }
    
}
