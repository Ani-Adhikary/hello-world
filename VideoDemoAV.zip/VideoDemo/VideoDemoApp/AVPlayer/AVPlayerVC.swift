import UIKit

class AVPlayerVC: UIViewController {
    
    let tableView: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Add the tableView to the view hierarchy
        view.addSubview(tableView)
        configureTableView()
    }
    
    private func configureTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.register(AVVidCell.self, forCellReuseIdentifier: "AVVidCell")
        
        view.addSubview(tableView)
        
        NSLayoutConstraint.activate([
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ])
    }
}

extension AVPlayerVC: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Return the number of rows in the section
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "AVVidCell", for: indexPath) as? AVVidCell else {
            fatalError("Unable to dequeue AVVidCell")
        }
        
        // Configure the cell
        cell.label.text = "This is a multiline label with a custom font. This is a multiline label with a custom font. This is a multiline label with a custom font.This is a multiline label with a custom font. This is a multiline label with a custom font."
        if let videoURL = URL(string: "http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4") {
            cell.videoURL = videoURL
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
}


