//
//  HelpVideoCell.swift
//  VideoDemoApp
//
//  Created by Ani Adhikary on 18/05/23.
//

import UIKit
import AVKit
import AVFoundation

class AVVidCell: UITableViewCell {
    var playerView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    var playerLayer: AVPlayerLayer!
    var player: AVPlayer!
    var videoURL: URL? {
        didSet {
            setupPlayer()
        }
    }
    
    let label: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 19)
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupUI()
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        player.pause()
        playerLayer.removeFromSuperlayer()
        playerLayer = nil
    }
    
    func setupUI() {
        contentView.addSubview(label)
        contentView.addSubview(playerView)
        
        NSLayoutConstraint.activate([
            label.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            label.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            label.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 16),
            
            playerView.topAnchor.constraint(equalTo: label.bottomAnchor, constant: 16),
            playerView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            playerView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            playerView.heightAnchor.constraint(equalToConstant: 350),
            playerView.widthAnchor.constraint(equalToConstant: 400),
            playerView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -16)
        ])
    }
    
    /*func setupPlayer() {
        guard let videoURL = videoURL else { return }
        
        player = AVPlayer(url: videoURL)
        playerLayer = AVPlayerLayer(player: player)
        playerLayer.frame = playerView.bounds
        playerView.layer.addSublayer(playerLayer)
        
        player.play()
    }*/
    
    func setupPlayer() {
        guard let videoURL = videoURL else { return }

        player = AVPlayer(url: videoURL)
        playerLayer = AVPlayerLayer(player: player)
        
        playerView.layer.addSublayer(playerLayer)
        
        // Update the layout of playerView
        playerView.layoutIfNeeded()
        
        playerLayer.frame = playerView.bounds

        player.play()
    }

}

