//
//  HelpVideoCell.swift
//  VideoDemoApp
//
//  Created by Ani Adhikary on 18/05/23.
//

import UIKit
import WebKit

class HelpVideoCell: UITableViewCell {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    let label: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0
        label.font = UIFont.systemFont(ofSize: 19)
        return label
    }()
    
    let webView: WKWebView = {
        let webView = WKWebView()
        webView.translatesAutoresizingMaskIntoConstraints = false
        return webView
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        contentView.addSubview(label)
        contentView.addSubview(webView)
        
        NSLayoutConstraint.activate([
            label.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 16),
            label.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            label.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            
            webView.topAnchor.constraint(equalTo: label.bottomAnchor, constant: 16),
            webView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            webView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            webView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -16),
            webView.widthAnchor.constraint(equalToConstant: 400),
            webView.heightAnchor.constraint(equalToConstant: 350)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
